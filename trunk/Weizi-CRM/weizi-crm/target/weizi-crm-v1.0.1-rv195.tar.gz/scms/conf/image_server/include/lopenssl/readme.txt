lopenssllib.c 目的 是 通过 lua调用openssl的rc4库进行解密文件
Makefile 则用于编译 lopenssllib.c文件


$make
$sudo make install
$sudo /sbin/ldconfig