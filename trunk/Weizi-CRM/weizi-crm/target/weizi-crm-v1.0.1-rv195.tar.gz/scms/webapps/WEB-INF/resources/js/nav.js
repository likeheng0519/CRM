var page_header_html ='<nav role="navigation" class="navbar navbar-default">'
page_header_html +='<div class="navbar-header text-center">';
page_header_html += '<a href="/project/home"> <img src="/resources/images/pepslogo.png"></a>';
page_header_html += '</div>';
page_header_html += '<div class="collapse navbar-collapse">';
//page_header_html += '<span><i class="fa fa-phone default-text"></i>Call Sales  (65) 6226 1138</span>';
page_header_html += '<ul class="nav navbar-nav nav-bg">';
page_header_html += '<li><a href="/project/manage">项目管理</a></li>';
page_header_html += '<li><a href="/user/manage">用户管理</a></li>';
//page_header_html += '<li><a href="department.html">部门管理</a></li>';
//page_header_html += '<li><a href="<%=basePath%>/project/home">项目管理</a></li>';
//page_header_html += '<li><a href="customer.html">客户管理</a></li>';
page_header_html += '<li><a href="/appeal/manage">申诉管理</a></li>';
//page_header_html += '<li><a href="settings.html">设置</a></li>';
page_header_html += '</ul>';
page_header_html += '<ul class="nav navbar-nav navbar-right">';
page_header_html += '<li><a href="#"><span class="glyphicon glyphicon-user"></span> 您好, <span id="user-name"></span> </a></li><li><a href="#">|</a></li>';
page_header_html += '<li><a href="#" onclick="$.LoginController.logout();"><span class="glyphicon glyphicon-log-out"></span> 退出</a></li>';
page_header_html += '</ul>';
page_header_html += '</div><!-- /.navbar-collapse -->';
page_header_html += '</nav>';





