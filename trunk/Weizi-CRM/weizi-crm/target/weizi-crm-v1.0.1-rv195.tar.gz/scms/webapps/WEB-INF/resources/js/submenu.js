var submenu_html ='<div class="submenu">'
/*submenu_html +='<div class="sub-1">';
submenu_html +='<div class="dropdown profile-element">';
submenu_html +='<span><img src="resources/images/p-2.jpg" class="img-circle" alt="image"></span>';
submenu_html +='<a href="#" class="dropdown-toggle" data-toggle="dropdown">';
submenu_html +='<span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">张三</strong></span>';
submenu_html +='<span class="text-muted text-xs block">管理员 <b class="caret"></b></span> </span>';
submenu_html +='</a>';
submenu_html +='<ul class="dropdown-menu animated fadeInRight m-t-xs">';
submenu_html +='<li><a href="profile.html"><span class="glyphicon glyphicon-cog"></span>&nbsp;设置</a></li>';
submenu_html +='<li class="divider"></li>';
submenu_html +='<li><a href="#"><span class="glyphicon glyphicon-off"></span>&nbsp;退出</a></li>';
submenu_html +='</ul>';
submenu_html +='</div>';
submenu_html +='<div class="logo-element">xx管理系统</div>';
submenu_html +='</div>';*/
submenu_html +='<ul class="list-unstyled">';
submenu_html +='<li><a href="department.html"><span class="glyphicon glyphicon-tasks"></span>部门管理</a></li>';
submenu_html +='<li><a href="<%=basePath%>/project/home"><span class="glyphicon glyphicon-book"></span>项目管理</a></li>';
submenu_html +='<li><a href="customer.html"><span class="glyphicon glyphicon-user"></span>客户管理</a></li>';
submenu_html +='<li><a href="user-manage.jsp"><span class="glyphicon glyphicon-user"></span>用户管理</a></li>';
submenu_html +='<li><a href="appeal.jsp"><span class="glyphicon glyphicon-list-alt"></span>申请单管理</a></li>';
submenu_html +=' </ul>';
submenu_html +='</div><!--end submenu-->';
